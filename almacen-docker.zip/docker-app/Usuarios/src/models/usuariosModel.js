const mysql = require('mysql2/promise');

const connection = mysql.createPool({
    host: 'mysql',
    user: 'root',
    password: 'juanes1321',
    database: 'capasAlmacen',
    port: '3306'
});

async function obtenerUsuarios() {
    const [rows] = await connection.query('SELECT id, nombres, apellidos, cedula, correo, telefono, direccion, rol FROM usuarios');
    return rows;
}

async function validar_password(correo, password) {
    // IMPORTANTE: Traemos el ROL para que el Front sepa quién es quién
    const [rows] = await connection.query(
        'SELECT id, nombres, apellidos, correo, rol FROM usuarios WHERE correo = ? AND password = ?',
        [correo, password]
    );
    return rows[0];
}

async function validar_password_admin(correo, password) {
    const [rows] = await connection.query(
        'SELECT id, nombres, apellidos, correo, rol FROM usuarios WHERE correo = ? AND password = ? AND rol = "admin"',
        [correo, password]
    );
    return rows[0];
}


async function obtenerUsuariosPorId(id) {
    const [rows] = await connection.query("SELECT * FROM usuarios WHERE id = ?", [id]);
    return rows[0];
}

async function crearUsuarios(nombres, apellidos, password, cedula, correo, telefono, direccion, rol = 'cliente') {
    const [result] = await connection.query(
        'INSERT INTO usuarios (nombres, apellidos, password, cedula, correo, telefono, direccion, rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [nombres, apellidos, password, cedula, correo, telefono, direccion, rol]
    );
    return result;
}

async function editarUsuarios(id, nombres, apellidos, password, cedula, correo, telefono, direccion, rol) {
    const [result] = await connection.query(
        'UPDATE usuarios SET nombres = ?, apellidos = ?, password = ?, cedula = ?, correo = ?, telefono = ?, direccion = ?, rol = ? WHERE id = ?',
        [nombres, apellidos, password, cedula, correo, telefono, direccion, rol, id]
    );
    return result;
}

async function eliminarUsuarios(id) {
    const [result] = await connection.query(
        'DELETE FROM usuarios WHERE id = ?',
        [id]
    );
    return result;
}

module.exports = {
    obtenerUsuarios,
    obtenerUsuariosPorId,
    crearUsuarios,
    editarUsuarios,
    eliminarUsuarios,
    validar_password
};