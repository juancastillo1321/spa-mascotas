const express = require('express');
const router = express.Router();
const axios = require('axios');
const ordenesModel = require('../models/ordenesModel');

router.get('/ordenes', async (req, res) => {
    try {
        const datos = await ordenesModel.traerOrdenes();
        res.json(datos);
    } catch (error) {
        res.status(500).json({ error: "Error de DB", detalle: error.message });
    }
});

router.post('/ordenes', async (req, res) => {
    try {
        const { usuario, items, fecha_reserva } = req.body;

        if (!fecha_reserva || !items) {
            return res.status(400).json({ error: "Faltan datos (fecha o items)" });
        }

        // --- VALIDACIÓN DE FECHA: SOLO HASTA 1 SEMANA DESPUÉS DE HOY ---
        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);

        const fechaReserva = new Date(fecha_reserva);
        fechaReserva.setHours(0, 0, 0, 0);

        const fechaMaxima = new Date(hoy);
        fechaMaxima.setDate(fechaMaxima.getDate() + 7);

        if (isNaN(fechaReserva.getTime())) {
            return res.status(400).json({ error: "La fecha de reserva no es válida" });
        }

        if (fechaReserva < hoy) {
            return res.status(400).json({ error: "No se puede reservar para una fecha anterior a hoy" });
        }

        if (fechaReserva > fechaMaxima) {
            return res.status(400).json({ error: "Solo se permiten reservas hasta máximo una semana después de la fecha actual" });
        }

        // --- VALIDACIÓN DE CUPO POR SERVICIO Y DÍA ---
        let total = 0;
        let nombresServicios = [];

        for (const item of items) {
            // 1. Consultamos al micro 3000 los detalles del producto
            const resProd = await axios.get(`http://localhost:3001/api/productos/${item.id}`);
            const producto = resProd.data;

            // 2. Contamos cuántas reservas existen de ESTE servicio en ESTA fecha
            const usadosHoy = await ordenesModel.contarCuposPorServicioYFecha(producto.nombre, fecha_reserva);

            // 3. Comparamos con el cupo máximo definido en la tabla 'servicio'
            if (usadosHoy >= producto.cupos) {
                return res.status(400).json({
                    error: `Cupos agotados para '${producto.nombre}' el día ${fecha_reserva}. (Máximo: ${producto.cupos})`
                });
            }

            // Si hay cupo, acumulamos para la orden
            total += Number(producto.precio) * item.cantidad;
            nombresServicios.push(producto.nombre);
        }

        // --- VALIDACIÓN DE USUARIO (3001) ---
        let dataUser;
        try {
            const resUser = await axios.get(`http://localhost:3000/api/usuarios/${usuario}`);
            dataUser = resUser.data;
        } catch (err) {
            return res.status(500).json({ error: "El micro de USUARIOS (3000) no responde" });
        }

        // --- CREACIÓN DE LA RESERVA ---
        const dataReserva = {
            idServicio: Number(items[0].id),
            nombreCliente: `${dataUser.nombres} ${dataUser.apellidos}`,
            emailCliente: dataUser.correo,
            precioTotal: total,
            nombreServicio: nombresServicios.join(", "),
            fecha: fecha_reserva,
            estado: 'pendiente'
        };

        const result = await ordenesModel.crearOrden(dataReserva);
         for (const item of items) {
            const resProd = await axios.get(`http://localhost:3001/api/productos/${item.id}`);
            const producto = resProd.data;

            const reservasActuales = await ordenesModel.contarCuposPorServicioYFecha(producto.nombre, fecha_reserva);

            if (reservasActuales >= producto.cupos) {
                await axios.patch(`http://localhost:3001/api/productos/${item.id}/estado`, {
                    estado: 'completado'
                });
            }
        }

        res.status(201).json({
            mensaje: "¡Reserva exitosa!",
            id: result.insertId
        });
    } catch (error) {
        console.error("Error General:", error.message);
        res.status(500).json({ error: "Error al procesar la reserva", detalle: error.message });
    }
});
router.get('/ordenes/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const orden = await ordenesModel.traerOrden(id);

        if (!orden) {
            return res.status(404).json({ error: "Orden no encontrada" });
        }

        res.json(orden);
    } catch (error) {
        console.error("Error al traer orden:", error.message);
        res.status(500).json({ error: "Error al traer la orden", detalle: error.message });
    }
});

router.delete('/ordenes/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const orden = await ordenesModel.traerOrden(id);
        if (!orden) {
            return res.status(404).json({ error: "Orden no encontrada" });
        }

        await ordenesModel.eliminarOrden(id);

        if (orden.idServicio) {
            const resProd = await axios.get(`http://localhost:3001/api/productos/${orden.idServicio}`);
            const producto = resProd.data;

            const reservasRestantes = await ordenesModel.contarCuposPorServicioYFecha(
                orden.nombreServicio,
                orden.fecha
            );

            if (reservasRestantes < producto.cupos && String(producto.estado).toLowerCase() === 'completado') {
                await axios.patch(`http://localhost:3001/api/productos/${orden.idServicio}/estado`, {
                    estado: 'activo'
                });
            }
        }

        res.json({ mensaje: "Orden eliminada" });
    } catch (error) {
        console.error("Error al eliminar orden:", error.message);
        res.status(500).json({ error: "Error al eliminar la orden", detalle: error.message });
    }
});
// NUEVA RUTA PARA DESCONTAR CUPOS (opcional pero recomendado)
router.patch('/ordenes/:id/descontar', async (req, res) => {
    try {
        const { id } = req.params;
        const orden = await ordenesModel.traerOrden(id);

        if (!orden) {
            return res.status(404).json({ error: "Orden no encontrada" });
        }

        // Aquí podríamos validar el estado de la orden antes de descontar
        const result = await ordenesModel.descontarCupoDirecto(orden.idServicio);

        if (!result) {
            return res.status(400).json({
                error: "No se pudo descontar el cupo (posiblemente sin cupos disponibles)"
            });
        }

        res.json({ mensaje: "Cupo descontado para la orden" });
    } catch (error) {
        console.error("Error al descontar cupo:", error.message);
        res.status(500).json({ error: "Error al descontar el cupo", detalle: error.message });
    }
});

router.put('/ordenes/:id/pagar', async (req, res) => {
    try {
        const { id } = req.params;

        const orden = await ordenesModel.traerOrden(id);

        if (!orden) {
            return res.status(404).json({ error: "Orden no encontrada" });
        }

        if (String(orden.estado).toLowerCase() === 'pagado') {
            return res.status(400).json({ error: "La orden ya está pagada" });
        }

        const result = await ordenesModel.marcarOrdenComoPagada(id);

        if (result.affectedRows === 0) {
            return res.status(400).json({ error: "No se pudo actualizar el estado de la orden" });
        }

        res.json({ mensaje: "Orden marcada como pagada" });
    } catch (error) {
        console.error("Error al pagar orden:", error.message);
        res.status(500).json({ error: "Error al actualizar el estado", detalle: error.message });
    }
});

module.exports = router;