const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: 'mysql',
    user: 'root',
    password: 'juanes1321',
    database: 'almacenOrdenes',
    port: 3306,
});

async function traerOrdenes() {
    try {
        const sql = `
            SELECT 
                id,
                nombreCliente,
                emailCliente,
                precioTotal,
                DATE_FORMAT(fecha, '%Y-%m-%d') AS fecha,
                nombreServicio,
                estado
            FROM reservas
        `;

        const [rows] = await pool.query(sql);
        return rows;
    } catch (error) {
        console.error("❌ ERROR EN MODELO (traerOrdenes):", error.message);
        throw error;
    }
}

const contarCuposPorServicioYFecha = async (nombreServicio, fecha) => {
    try {
        const sql = `SELECT COUNT(*) as total FROM reservas WHERE nombreServicio LIKE ? AND DATE(fecha) = ?`;
        const [rows] = await pool.query(sql, [`%${nombreServicio}%`, fecha]);
        return rows[0].total;
    } catch (error) {
        console.error("❌ ERROR EN MODELO (contarCupos):", error.message);
        throw error;
    }
};

async function crearOrden(orden) {
    try {
        const { id, nombreCliente, emailCliente, precioTotal, nombreServicio, fecha, estado } = orden;

        const sql = `
            INSERT INTO reservas (id, nombreCliente, emailCliente, precioTotal, fecha, nombreServicio, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        const [result] = await pool.query(sql, [
            id,
            nombreCliente,
            emailCliente,
            precioTotal,
            fecha,
            nombreServicio,
            estado || 'pendiente'
        ]);

        return result;
    } catch (error) {
        console.error("❌ ERROR EN MODELO (crearOrden):", error.message);
        throw error;
    }
}

async function traerOrden(id) {
    try {
        const [rows] = await pool.query('SELECT * FROM reservas WHERE id = ?', [id]);
        return rows[0];
    } catch (error) {
        console.error("❌ ERROR EN MODELO (traerOrden):", error.message);
        throw error;
    }
}

async function eliminarOrden(id) {
    try {
        const [result] = await pool.query('DELETE FROM reservas WHERE id = ?', [id]);
        return result;
    } catch (error) {
        console.error("❌ ERROR EN MODELO (eliminarOrden):", error.message);
        throw error;
    }
}

async function marcarOrdenComoPagada(id) {
    try {
        const sql = 'UPDATE reservas SET estado = ? WHERE id = ?';
        const [result] = await pool.query(sql, ['pagado', id]);
        return result;
    } catch (error) {
        console.error("❌ ERROR EN MODELO (marcarOrdenComoPagada):", error.message);
        throw error;
    }
}

module.exports = {
    traerOrdenes,
    crearOrden,
    traerOrden,
    eliminarOrden,
    contarCuposPorServicioYFecha,
    marcarOrdenComoPagada
};