-- Crear bases de datos
CREATE DATABASE IF NOT EXISTS capasAlmacen;
CREATE DATABASE IF NOT EXISTS almacenServicios;
CREATE DATABASE IF NOT EXISTS almacenOrdenes;

-- =====================
-- Base de datos Usuarios
-- =====================
USE capasAlmacen;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT NOT NULL AUTO_INCREMENT,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    cedula VARCHAR(20) NOT NULL,
    correo VARCHAR(120) NOT NULL,
    telefono VARCHAR(20) NULL,
    direccion VARCHAR(150) NULL,
    rol ENUM('admin', 'cliente') NULL DEFAULT 'cliente',
    `password` VARCHAR(255) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_usuarios_cedula (cedula),
    UNIQUE KEY uq_usuarios_correo (correo)
);

-- Usuario admin por defecto
INSERT IGNORE INTO usuarios (nombres, apellidos, cedula, correo, telefono, direccion, rol, password)
VALUES ('Admin', 'Sistema', '0000000000', 'admin@admin.com', '0000000000', 'Sistema', 'admin', 'admin123');

-- =====================
-- Base de datos Servicios
-- =====================
USE almacenServicios;

CREATE TABLE IF NOT EXISTS servicio (
    id INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(60) NULL,
    precio DECIMAL(10,2) NULL,
    detalle VARCHAR(100) NULL,
    marca VARCHAR(30) NULL,
    estado ENUM('activo', 'inhabilitado', 'completado') NULL,
    cupos INT NULL DEFAULT 10,
    PRIMARY KEY (id)
);

-- =====================
-- Base de datos Ordenes
-- =====================
USE almacenOrdenes;

CREATE TABLE IF NOT EXISTS reservas (
    id INT NOT NULL AUTO_INCREMENT,
    nombreCliente VARCHAR(50) NULL,
    emailCliente VARCHAR(50) NULL,
    precioTotal DECIMAL(10,2) NULL,
    fecha DATETIME NULL,
    nombreServicio VARCHAR(50) NULL,
    estado ENUM('pendiente', 'pagado', 'cancelado') NULL DEFAULT 'pendiente',
    PRIMARY KEY (id)
);
