const mysql = require('mysql2/promise'); 
 
const connection = mysql.createPool({ 
    host: 'mysql', 
    user: 'root', 
    password: 'juanes1321', 
    database: 'almacenServicios' 
}); 
 
async function obtenerProductos() { 
    const result = await connection.query('SELECT * FROM servicio'); 
    return result[0]; 
} 

async function obtenerProductoPorId(id) {
    const result = await connection.query(
        'SELECT * FROM servicio WHERE id = ?',
        [id]
    );
    return result[0][0]; 
}

// MODIFICACIÓN: Agregamos cupos_maximos a la inserción
async function crearProducto(nombre, precio, detalle, marca, estado, cupos) { 
    // Usamos los nombres de las columnas para que sea más seguro
    const sql = 'INSERT INTO servicio (nombre, precio, detalle, marca, estado, cupos) VALUES(?,?,?,?,?,?)';
    const result = await connection.query(sql, [nombre, precio, detalle, marca, estado, cupos]); 
    return result; 
} 

// MODIFICACIÓN: Agregamos cupos_maximos a la actualización
// En productosModel.js

// En productosModel.js

async function editarProducto(id, nombre, precio, detalle, marca, estado, cupos) {
    // Esta consulta ignora el "estado" que envía el usuario si detecta que hay cupos.
    // Es la única forma de asegurar que el estado sea coherente con el inventario.
    const sql = `
        UPDATE servicio 
        SET nombre = ?, 
            precio = ?, 
            detalle = ?, 
            marca = ?, 
            cupos = ?,
            estado = CASE 
                WHEN ? > 0 AND estado IN ('completado', 'inhabilitado') THEN 'activo'
                WHEN ? <= 0 THEN 'completado'
                ELSE ? 
            END
        WHERE id = ?`;

    // Pasamos 'cupos' dos veces para las validaciones del CASE y 'estado' como respaldo
    const result = await connection.query(sql, [
        nombre, 
        precio, 
        detalle, 
        marca, 
        cupos,  // Para la columna cupos
        cupos,  // Para el primer WHEN (activar si > 0)
        cupos,  // Para el segundo WHEN (completar si <= 0)
        estado, // El estado original (por si no entra en ninguna regla)
        id
    ]);
    return result;
}
// Esta es la función que deberías llamar cuando alguien cancela una reserva
async function reponerCupo(id) {
    // Incrementa cupo y SI el estado era completado/inhabilitado, lo pasa a activo.
    const sql = `
        UPDATE servicio 
        SET cupos = cupos + 1,
            estado = IF(estado IN ('completado', 'inhabilitado'), 'activo', estado)
        WHERE id = ?`;
    
    const [result] = await connection.query(sql, [id]);
    return result.affectedRows > 0;
}

// NUEVA FUNCIÓN: Para que el micro de Órdenes descuente el cupo


async function eliminarProducto(id) {
    const result = await connection.query(
        'DELETE FROM servicio WHERE id = ?',
        [id]
    );
    return result;
}
async function actualizarEstadoProducto(id, estado) {
    const sql = 'UPDATE servicio SET estado = ? WHERE id = ?';
    const [result] = await connection.query(sql, [estado, id]);
    return result;
}
// En productosModel.js
async function descontarCupo(id) {
    // 1. Descontamos el cupo
    const sqlDesc = 'UPDATE servicio SET cupos = cupos - 1 WHERE id = ? AND cupos > 0';
    const [result] = await connection.query(sqlDesc, [id]);

    if (result.affectedRows > 0) {
        // 2. Si después de descontar el cupo es 0, lo inhabilitamos
        const sqlCheck = 'UPDATE servicio SET estado = "inhabilitado" WHERE id = ? AND cupos = 0';
        await connection.query(sqlCheck, [id]);
        return true;
    }
    return false;
}



module.exports = { 
    obtenerProductos, 
    obtenerProductoPorId,
    crearProducto,
    editarProducto,
    eliminarProducto,
    descontarCupo,
    actualizarEstadoProducto,
    reponerCupo
};
 
